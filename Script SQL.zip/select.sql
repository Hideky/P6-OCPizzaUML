# Nombre de pizza différente commander par l'utilisateur 5
SELECT count(*) FROM ocpizza.ordered 
JOIN ocpizza.orders ON orders.order_id = ordered.order_id
WHERE orders.client_id = 5

# Nombre de pizza différente commander par l'utilisateur Jaina
SELECT count(*) FROM ocpizza.ordered 
JOIN ocpizza.orders ON orders.order_id = ordered.order_id 
JOIN ocpizza.client ON orders.client_id = client.client_id 
WHERE client.firstname = 'Jaina'

# Ingrédient necessaire pour faire la pizza au saumon
SELECT ingredient.name, compound.quantity FROM ocpizza.ingredient 
JOIN ocpizza.compound ON ingredient.ingredient_id = compound.ingredient_id 
JOIN ocpizza.product ON product.product_id = compound.product_id 
WHERE product.name = 'Pizza au Saumon'

# Contenu de la commande 1
SELECT product.name, ordered.quantity FROM ocpizza.product 
JOIN ocpizza.ordered ON ordered.product_id = product.product_id 
JOIN ocpizza.orders ON orders.order_id = ordered.order_id 
WHERE orders.order_id = 1

# Nombre de pizza total commandé dans la commande 1
SELECT sum(ordered.quantity) FROM ocpizza.product 
JOIN ocpizza.ordered ON ordered.product_id = product.product_id 
JOIN ocpizza.orders ON orders.order_id = ordered.order_id 
WHERE orders.order_id = 1